1)
	Lancer le script Basededonnée.py -->
	Nom de la base de donnée : Boxe
	Nom d'utilisateur : root
	Mot de passe : 
"Pour l'IUT ça sera surement admin et admin cela dépend de l'environnement"

2)
	Lancer le script main.py
	Nom de la base de donnée : Boxe
	Nom d'utilisateur : root
	Mot de passe : 
"Pour l'IUT ça sera surement admin et admin cela dépend de l'environnement"

(Au cas ou un problème se pose au niveau de la connection, il faudra bien vérifier si le nom
d'utilisateur, Base et mot de passe convienne sur main.py ainsi que Basededonée.py et utilisateur.py)

3) La navbar du site peut renconter quelques petit problèmes d'affichages mais cela fonctionne dans l'ensemble

4) Pour la table "Score" il peut y avoir des problèmes pour la page afficher les scores

Remarque : 

- Basededonnée.py permet la création de la base avec directement les tables.
-Les fichiers csv permettes de stocker les données des divers table, et elle
permette d'avoir un aperçue pour le jeu d'essai
- utilisateur.py contiens toutes les fonctions python et main.py contients toutes les fonctions cherrypy de l'appli WEB.



5) Par rapport à l'étape 2 j'ai du rajouter une table score pour ma partie dynamique.

6) En tant que fonctionnalités non réalisés je dirais plus que je suis asser déçu du rendu de la page add_score et de ses fonctionnalités ainsi que le css du site en général que je comptais développer encore plus.


