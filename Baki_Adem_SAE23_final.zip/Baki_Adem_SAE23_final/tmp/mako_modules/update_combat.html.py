# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094856.098878
_enable_loop = True
_template_filename = 'res/templates/update_combat.html'
_template_uri = 'update_combat.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        combats = context.get('combats', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/update_combat.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>TBA - The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li class="active"><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        <div class="main">\r\n            <div class="content">\r\n                <form method="post" action="update_combat_done">\r\n                    <label for="id_combat">ID du Combat :</label><br>\r\n                    <input type="text" id="id_combat" name="id_combat" required><br>\r\n                    <label for="date">Date :</label><br>\r\n                    <input type="date" id="date" name="date"><br>\r\n                    <label for="categorie">Catégorie :</label><br>\r\n                    <input type="text" id="categorie" name="categorie"><br>\r\n                    <label for="lieu">Lieu :</label><br>\r\n                    <select id="lieu" name="lieu">\r\n                        <option value="Paris">Paris</option>\r\n                        <option value="Lyon">Lyon</option>\r\n                        <option value="Marseille">Marseille</option>\r\n                        <option value="Grenoble">Grenoble</option>\r\n                        <option value="Lille">Lille</option>\r\n                        <option value="Saint Etienne">Saint Etienne</option>\r\n                    </select><br>         \r\n                    <input type="submit" value="Mettre à jour">   \r\n                </form>                \r\n            </div>\r\n            <div class="combat-list">\r\n                <h2>Combats</h2>\r\n                <table class="table">\r\n                    <thead>\r\n                        <tr>\r\n                            <th>ID</th>\r\n                            <th>Date</th>\r\n                            <th>Boxeur 1</th>\r\n                            <th>Points 1</th>\r\n                            <th>Boxeur 2</th>\r\n                            <th>Points 2</th>\r\n                            <th>Gagnant</th>\r\n                            <th>Méthode de victoire</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n')
        for combat in combats:
            __M_writer('                        <tr>\r\n                            <td>')
            __M_writer(str(combat['combat_id']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(combat['combat_date']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(combat['boxeur1']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(combat['points1']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(combat['boxeur2']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(combat['points2']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(combat['winner_id']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(combat['win_method']))
            __M_writer('</td>\r\n                        </tr>\r\n')
        __M_writer('                    </tbody>\r\n                </table>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/update_combat.html", "uri": "update_combat.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 92, "24": 93, "25": 94, "26": 94, "27": 95, "28": 95, "29": 96, "30": 96, "31": 97, "32": 97, "33": 98, "34": 98, "35": 99, "36": 99, "37": 100, "38": 100, "39": 101, "40": 101, "41": 104, "47": 41}}
__M_END_METADATA
"""
