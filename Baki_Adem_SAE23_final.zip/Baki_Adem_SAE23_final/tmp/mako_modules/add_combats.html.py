# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094855.107283
_enable_loop = True
_template_filename = 'res/templates/add_combats.html'
_template_uri = 'add_combats.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message_error = context.get('message_error', UNDEFINED)
        result = context.get('result', UNDEFINED)
        boxers = context.get('boxers', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/add_combats.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>TBA - The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li class="active"><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        <div class="main">\r\n            <form action="add_combat_done" method="post">\r\n                <label for="date">Date du combat: </label><br>\r\n                <input type="date" id="date" name="date" required><br>\r\n                <label for="boxeur1_id">ID du premier boxeur: </label><br>\r\n                <input type="text" id="boxeur1_id" name="boxeur1_id" required><br>\r\n                <label for="boxeur2_id">ID du deuxième boxeur: </label><br>\r\n                <input type="text" id="boxeur2_id" name="boxeur2_id" required><br>\r\n                <label for="lieu_choice">Lieu du combat: </label><br>\r\n                <select name="lieu_choice" id="lieu_choice" required>\r\n                    <option value="1">Paris</option>\r\n                    <option value="2">Lyon</option>\r\n                    <option value="3">Marseille</option>\r\n                    <option value="4">Grenoble</option>\r\n                    <option value="5">Lille</option>\r\n                    <option value="6">Saint Etienne</option>\r\n                </select><br>\r\n                <label for="result_choice">Résultat du combat: </label><br>\r\n                <select name="result_choice" id="result_choice" required>\r\n                    <option value="1">KO</option>\r\n                    <option value="2">Points</option>\r\n                </select><br>\r\n                <label for="winner_id">ID du boxeur gagnant: </label><br>\r\n                <input type="text" id="winner_id" name="winner_id" required><br>\r\n                <input type="submit" value="Ajouter">\r\n            </form>\r\n\r\n            <!-- New table for displaying boxers -->\r\n            <div class="boxer-list">\r\n                <p>')
        __M_writer(str(message_error))
        __M_writer('</p>\r\n                <p>')
        __M_writer(str(result))
        __M_writer('</p>\r\n                <h2>Liste des Boxeurs :</h2>\r\n                <table class="table">\r\n                    <thead>\r\n                        <tr>\r\n                            <th>ID</th>\r\n                            <th>Nom</th>\r\n                            <!-- Add more table headers based on your boxer\'s attributes -->\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n')
        for boxer in boxers:
            __M_writer('                        <tr>\r\n                            <td>')
            __M_writer(str(boxer['id']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(boxer['nom']))
            __M_writer("</td>\r\n                            <!-- Fill in the rest of the table data based on your boxer's attributes -->\r\n                        </tr>\r\n")
        __M_writer('                    </tbody>\r\n                </table>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>\r\n    <script src="/static/js/add_combats.js"></script>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/add_combats.html", "uri": "add_combats.html", "source_encoding": "utf-8", "line_map": {"16": 0, "24": 1, "25": 84, "26": 84, "27": 85, "28": 85, "29": 96, "30": 97, "31": 98, "32": 98, "33": 99, "34": 99, "35": 103, "41": 35}}
__M_END_METADATA
"""
