# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094865.9635587
_enable_loop = True
_template_filename = 'res/templates/add_score.html'
_template_uri = 'add_score.html'
_source_encoding = 'utf-8'
_exports = []


 
from utilisateur import get_juges_byID 
from utilisateur import conn
            

def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        scores = context.get('scores', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/index.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>TBA - The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li class="active"><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        <div class="main">\r\n            <form action="add_score_done" method="post">\r\n                <label for="juge_id">ID du juge: </label><br>\r\n                <input type="text" id="juge_id" name="juge_id" required><br>\r\n                <label for="combat_id">ID du combat: </label><br>\r\n                <input type="text" id="combat_id" name="combat_id" required><br>\r\n                <label for="round_number">Numéro du round: </label><br>\r\n                <input type="number" id="round_number" name="round_number" required><br>\r\n                <label for="score_boxer1">Score du premier boxeur: </label><br>\r\n                <input type="number" id="score_boxer1" name="score_boxer1" required><br>\r\n                <label for="score_boxer2">Score du deuxième boxeur: </label><br>\r\n                <input type="number" id="score_boxer2" name="score_boxer2" required><br>\r\n                <input type="submit" value="Ajouter">\r\n            </form>\r\n            <!-- New table for displaying scores -->\r\n            ')
        __M_writer('\r\n\r\n            <div class="score-list">\r\n                <h2>Liste des Scores :</h2>\r\n                <table class="table">\r\n                    <thead>\r\n                        <tr>\r\n                            <th>ID Combat</th>\r\n                            <th>ID Juge</th>\r\n                            <th>Round</th>\r\n                            <th>Score Boxeur 1</th>\r\n                            <th>Score Boxeur 2</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n')
        for score in scores:
            __M_writer('                        <tr>\r\n                            <td>')
            __M_writer(str(score['combat_id']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(get_juges_byID(conn, score['juge_id'])))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(score['round_number']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(score['score_boxer1']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(score['score_boxer2']))
            __M_writer('</td>\r\n                        </tr>\r\n')
        __M_writer('                    </tbody>\r\n                </table>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>\r\n    <script src="/static/js/index.js"></script>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/add_score.html", "uri": "add_score.html", "source_encoding": "utf-8", "line_map": {"16": 70, "17": 71, "18": 72, "19": 73, "20": 74, "21": 0, "27": 1, "28": 73, "29": 88, "30": 89, "31": 90, "32": 90, "33": 91, "34": 91, "35": 92, "36": 92, "37": 93, "38": 93, "39": 94, "40": 94, "41": 97, "47": 41}}
__M_END_METADATA
"""
