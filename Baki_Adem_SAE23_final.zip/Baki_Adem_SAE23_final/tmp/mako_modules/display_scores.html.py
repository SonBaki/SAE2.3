# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094865.2137425
_enable_loop = True
_template_filename = 'res/templates/display_scores.html'
_template_uri = 'display_scores.html'
_source_encoding = 'utf-8'
_exports = []


 
from utilisateur import get_juges_byID 
from utilisateur import conn
        

def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        scores = context.get('scores', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/display_scores.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>TBA - The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li class="active"><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        ')
        __M_writer('\r\n\r\n            <div class="score-list">\r\n                <h2>Liste des Scores :</h2>\r\n                <table class="table">\r\n                    <thead>\r\n                        <tr>\r\n                            <th>ID Combat</th>\r\n                            <th>ID Juge</th>\r\n                            <th>Round</th>\r\n                            <th>Score Boxeur 1</th>\r\n                            <th>Score Boxeur 2</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n')
        for score in scores:
            __M_writer('                        <tr>\r\n                            <td>')
            __M_writer(str(score['combat_id']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(get_juges_byID(conn, score['juge_id'])))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(score['round_number']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(score['score_boxer1']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(score['score_boxer2']))
            __M_writer('</td>\r\n                        </tr>\r\n')
        __M_writer('                    </tbody>\r\n                </table>\r\n            </div>\r\n    </div>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/display_scores.html", "uri": "display_scores.html", "source_encoding": "utf-8", "line_map": {"16": 55, "17": 56, "18": 57, "19": 58, "20": 59, "21": 0, "27": 1, "28": 58, "29": 73, "30": 74, "31": 75, "32": 75, "33": 76, "34": 76, "35": 77, "36": 77, "37": 78, "38": 78, "39": 79, "40": 79, "41": 82, "47": 41}}
__M_END_METADATA
"""
