# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094861.7874014
_enable_loop = True
_template_filename = 'res/templates/update_juge.html'
_template_uri = 'update_juge.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        juges = context.get('juges', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/update_juge.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>TBA - The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li class="active"><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        <div class="content">\r\n            <form action="update_juge_done" method="post">\r\n                <label for="id_juge">ID du juge :</label>\r\n                <input type="number" id="id_juge" name="id_juge" required><br>\r\n                <label for="nom">Nom :</label>\r\n                <input type="text" id="nom" name="nom"><br>\r\n                <label for="prenom">Prénom :</label>\r\n                <input type="text" id="prenom" name="prenom"><br>\r\n                <input type="submit" value="Mettre à jour">\r\n            </form>\r\n        </div>\r\n        <div class="content">\r\n            <h2>Liste des juges :</h2>\r\n            <ul>\r\n')
        for juge in juges:
            __M_writer('                <li>ID: ')
            __M_writer(str(juge['id']))
            __M_writer(', Nom: ')
            __M_writer(str(juge['nom']))
            __M_writer(', Prénom: ')
            __M_writer(str(juge['prenom']))
            __M_writer('</li>\r\n')
        __M_writer('            </ul>\r\n        </div>        \r\n    </div>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/update_juge.html", "uri": "update_juge.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 69, "24": 70, "25": 70, "26": 70, "27": 70, "28": 70, "29": 70, "30": 70, "31": 72, "37": 31}}
__M_END_METADATA
"""
