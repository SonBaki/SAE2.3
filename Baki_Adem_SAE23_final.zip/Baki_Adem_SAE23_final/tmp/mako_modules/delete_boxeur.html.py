# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686095224.4017406
_enable_loop = True
_template_filename = 'res/templates/delete_boxeur.html'
_template_uri = 'delete_boxeur.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        type = context.get('type', UNDEFINED)
        boxeurs = context.get('boxeurs', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/delete_boxeur.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>TBA - The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li class="active"><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        <div class="content">\r\n')
        if message:
            __M_writer('                <div class="alert alert-')
            __M_writer(str(type))
            __M_writer('">')
            __M_writer(str(message))
            __M_writer('</div>\r\n')
        __M_writer('            \r\n            <form method="post" action="delete_boxeur">\r\n                <label for="id">ID du Boxeur :</label><br>\r\n                <input type="text" id="id" name="id"><br>\r\n                <input type="submit" value="Supprimer">\r\n            </form>\r\n            <h2>Liste des Boxeurs</h2>\r\n            <table>\r\n                <tr>\r\n                    <th>ID</th>\r\n                    <th>Nom</th>\r\n                    <th>Prénom</th>\r\n                    <!-- Autres colonnes selon vos besoins -->\r\n                </tr>\r\n')
        for boxeur in boxeurs:
            __M_writer('                    <tr>\r\n                        <td>')
            __M_writer(str(boxeur['id']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(boxeur['nom']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(boxeur['prenom']))
            __M_writer('</td>\r\n                        <!-- Autres colonnes selon vos besoins -->\r\n                    </tr>\r\n')
        __M_writer('            </table>\r\n        </div>\r\n    </div>\r\n    <script src="/static/js/jquery-3.7.0.min.js"></script>\r\n    <script src="/static/js/index.js"></script>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/delete_boxeur.html", "uri": "delete_boxeur.html", "source_encoding": "utf-8", "line_map": {"16": 0, "24": 1, "25": 56, "26": 57, "27": 57, "28": 57, "29": 57, "30": 57, "31": 59, "32": 73, "33": 74, "34": 75, "35": 75, "36": 76, "37": 76, "38": 77, "39": 77, "40": 81, "46": 40}}
__M_END_METADATA
"""
