# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094826.3250487
_enable_loop = True
_template_filename = 'res/templates/add_juge.html'
_template_uri = 'add_juge.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        juges = context.get('juges', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/index.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>TBA - The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li class="active"><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        <div class="main">\r\n            <div class="content">\r\n                <form action="add_juge_done" method="post">\r\n                    <label for="nom">Nom:</label><br>\r\n                    <input type="text" id="nom" name="nom" required><br>\r\n                    <label for="prenom">Prénom:</label><br>\r\n                    <input type="text" id="prenom" name="prenom" required><br>\r\n                    <input type="submit" value="Ajouter">\r\n                </form>\r\n            </div>\r\n            <div class="juge-list">\r\n                <h2>Juges existants :</h2>\r\n                <ul>\r\n')
        for juge in juges:
            __M_writer('                        <li>')
            __M_writer(str(juge['prenom']))
            __M_writer(' ')
            __M_writer(str(juge['nom']))
            __M_writer('</li>\r\n')
        __M_writer('                </ul>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>\r\n    <script src="/static/js/index.js"></script>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/add_juge.html", "uri": "add_juge.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 68, "24": 69, "25": 69, "26": 69, "27": 69, "28": 69, "29": 71, "35": 29}}
__M_END_METADATA
"""
