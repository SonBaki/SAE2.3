# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094850.7756846
_enable_loop = True
_template_filename = 'res/templates/add_boxeur.html'
_template_uri = 'add_boxeur.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        success_message = context.get('success_message', UNDEFINED)
        error_message = context.get('error_message', UNDEFINED)
        boxeurs = context.get('boxeurs', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/add_boxeur.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>TBA - The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li class="active"><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        <div class="content">\r\n            <form method="post" action="add_boxeur">\r\n                <!-- Insertion du message d\'erreur -->\r\n')
        if error_message:
            __M_writer('                    <div class="error_message">')
            __M_writer(str(error_message))
            __M_writer('</div>\r\n')
        __M_writer('\r\n                <!-- Insertion du message de succès -->\r\n')
        if success_message:
            __M_writer('                    <div class="success_message">')
            __M_writer(str(success_message))
            __M_writer('</div>\r\n')
        __M_writer('\r\n                <label for="nom">Nom :</label><br>\r\n                <input type="text" id="nom" name="nom"><br>\r\n                <label for="prenom">Prénom :</label><br>\r\n                <input type="text" id="prenom" name="prenom"><br>\r\n                <label for="categorie">Catégorie :</label><br>\r\n                <select id="categorie_choice" name="categorie_choice">\r\n                    <option value="Légers">Légers</option>\r\n                    <option value="Mi-moyen">Mi-moyen</option>\r\n                    <option value="Mi-lourds">Mi-lourds</option>\r\n                    <option value="Lourds">Lourds</option>\r\n                </select><br>\r\n                <input type="submit" value="Ajouter">\r\n            </form>\r\n\r\n            <!-- Affichage des boxeurs existants -->\r\n            <h2>Boxeurs existants :</h2>\r\n')
        for boxeur in boxeurs:
            __M_writer('                <p>')
            __M_writer(str(boxeur['nom']))
            __M_writer(' ')
            __M_writer(str(boxeur['prenom']))
            __M_writer(' - Catégorie: ')
            __M_writer(str(boxeur['categorie']))
            __M_writer('</p>\r\n')
        __M_writer('        </div>\r\n    </div>\r\n    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>\r\n    <script src="/static/js/add_boxeur.js"></script>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/add_boxeur.html", "uri": "add_boxeur.html", "source_encoding": "utf-8", "line_map": {"16": 0, "24": 1, "25": 58, "26": 59, "27": 59, "28": 59, "29": 61, "30": 63, "31": 64, "32": 64, "33": 64, "34": 66, "35": 83, "36": 84, "37": 84, "38": 84, "39": 84, "40": 84, "41": 84, "42": 84, "43": 86, "49": 43}}
__M_END_METADATA
"""
