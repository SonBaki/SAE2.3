# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094848.4851627
_enable_loop = True
_template_filename = 'res/templates/display_boxeur.html'
_template_uri = 'display_boxeur.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        boxeurs = context.get('boxeurs', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <title>TBA - The Boxing Addict</title>\r\n    <link rel="stylesheet" href="/static/css/display_boxeur.css">\r\n</head>\r\n<body>\r\n    <div class="container">\r\n        <div class="header">\r\n            <h1>Welcome to The Boxing Addict</h1>\r\n        </div>\r\n        <div class="navbar-collapse collapse">\r\n            <ul class="navbar-nav pull-right">\r\n                <li>\r\n                    <a href="index">Présentation</a>\r\n                </li>\r\n                <li class="active">\r\n                    <a href="#" class="dropdown-toggle">Boxeurs</a>\r\n                    <ul class="sub-menu">\r\n                        <li class="active"><a href="display_boxeur">Afficher les Boxeurs</a></li>\r\n                        <li><a href="add_boxeur">Ajouter un Boxeur</a></li>\r\n                        <li><a href="update_boxeur">Modifier un Boxeur</a></li>\r\n                        <li><a href="delete_boxeur">Supprimer un Boxeur</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Combats</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_combats">Afficher les Combats</a></li>\r\n                        <li><a href="add_combats">Ajouter un Combat</a></li>\r\n                        <li><a href="update_combat">Modifier un Combat</a></li>\r\n                        <li><a href="delete_combat">Supprimer un Combat</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Juges</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_juges">Afficher les Juges</a></li>\r\n                        <li><a href="add_juge">Ajouter un Juge</a></li>\r\n                        <li><a href="update_juge">Modifier un Juge</a></li>\r\n                        <li><a href="delete_juge">Supprimer un Juge</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li>\r\n                    <a href="#" class="dropdown-toggle">Scores</a>\r\n                    <ul class="sub-menu">\r\n                        <li><a href="display_scores">Afficher les Scores</a></li>\r\n                        <li><a href="add_score">Ajouter un Score</a></li>\r\n                        <li><a href="delete_scores">Supprimer un Score</a></li>\r\n                        <li><a href="update_scores">Modifier un score</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>        \r\n        <div class="content">\r\n            <h2>Liste des boxeurs :</h2>\r\n            <table>\r\n                <tr>\r\n                    <th>ID</th>\r\n                    <th>Nom</th>\r\n                    <th>Catégorie</th>\r\n                </tr>\r\n')
        for boxeur in boxeurs:
            __M_writer('                    <tr>\r\n                        <td>')
            __M_writer(str(boxeur['id']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(boxeur['nom']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(boxeur['categorie']))
            __M_writer('</td>\r\n                    </tr>\r\n')
        __M_writer('            </table>\r\n        </div>\r\n    </div>\r\n    <script src="/static/js/index.js"></script>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/display_boxeur.html", "uri": "display_boxeur.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 63, "24": 64, "25": 65, "26": 65, "27": 66, "28": 66, "29": 67, "30": 67, "31": 70, "37": 31}}
__M_END_METADATA
"""
