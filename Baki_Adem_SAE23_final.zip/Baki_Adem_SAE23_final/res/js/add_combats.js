document.addEventListener('DOMContentLoaded', function() {
    var dropdownToggles = document.querySelectorAll('.dropdown-toggle');
    dropdownToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            var subMenu = this.nextElementSibling;
            subMenu.style.display = subMenu.style.display === 'none' ? 'block' : 'none';
        });
    });

    var resultChoice = document.getElementById('result_choice');
    var pointFields = document.querySelectorAll('.points');
    var koBoxerField = document.getElementById('ko_boxer_id');

    resultChoice.addEventListener('change', function() {
        if (this.value === '2') {  // si KO est sélectionné
            pointFields.forEach(function(field) {
                field.setAttribute('disabled', 'disabled');
            });
            koBoxerField.removeAttribute('disabled');
        } else {  // si Points est sélectionné
            pointFields.forEach(function(field) {
                field.removeAttribute('disabled');
            });
            koBoxerField.setAttribute('disabled', 'disabled');
        }
    });
});

